'use strict';

const functions = require('firebase-functions');
const admin = require('firebase-admin');
const {WebhookClient} = require('dialogflow-fulfillment');
admin.initializeApp({
  	credential: admin.credential.applicationDefault(), 
  	databaseURL:"ws://cokebot-fjjn-377ca.firebaseio.com/"
});
//const db = admin.firestore();

process.env.DEBUG = 'dialogflow:debug'; // enables lib debugging statements

exports.dialogflowFirebaseFulfillment = functions.https.onRequest((request, response) => {
  const agent = new WebhookClient({ request, response });

  function product_name(agent) {
    const productname = agent.parameters.products;
    const quantityno = agent.parameters.number;
    agent.add(`Do you want anything more ? Yes/No`);
    return admin.database().ref('data').set({
    	product: productname,
    	quantity: quantityno});
    //db.collection("product").Push({ product: productname });
    
  }
  
  function quantity_no(agent) {
    const quantityno = agent.parameters.number;
    //db.collection("quantity").Push({ quantity: quantityno });
    agent.add(`Do you want anything more ? Yes/No`);
    return admin.database().ref('data').set({
    	quantity: quantityno});
  }
  
  function end_no(agent) {
    let productname = agent.parameters.products;
    let quantityno = agent.parameters.number;
    agent.add(`Thanking you for shopping from CokeBot. Keep Ordering`);
    return admin.database().ref('data').once("value").then(function(snapshot) {
    var product = snapshot.child("product").val(); 
    var quantity = snapshot.child("quantity").val(); 
    if(product != null){
      agent.add(`You have Ordered ${product}`);
    		}
    if(quantity != null){
      agent.add(`You have ${quantity} quantity`);
    		}
    
  });
  }

  let intentMap = new Map();
  intentMap.set('finalsave', product_name);
  //intentMap.set('finalsave', quantity_no);
  intentMap.set('no_intent', end_no);
  agent.handleRequest(intentMap);
});